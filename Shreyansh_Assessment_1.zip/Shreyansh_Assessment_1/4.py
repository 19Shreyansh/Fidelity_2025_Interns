'''Name = Shreyansh Srivastava'''
'''Questions = 1,4,7,8,10'''
'''Email Address = shreyanshsri19@gmail.com'''

from abc import *

class bank(ABC):
    def bank_info(self):
        print("Welcome to Bank")
    @abstractmethod
    def interest(self):
        pass

class hdfc(bank):
    def interest(self):
        print("Interest Rate of HDFC is 7%")

class sbi(bank):
    def interest(self):
        print("Interest Rate of SBI is 5%")

HDFC=hdfc()
SBI=sbi()

HDFC.bank_info()
HDFC.interest()

SBI.bank_info()
SBI.interest()